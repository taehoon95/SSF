package liveStreaming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiveStreamingApplicationTests {

	@Test
	void contextLoads() {
	}

}
